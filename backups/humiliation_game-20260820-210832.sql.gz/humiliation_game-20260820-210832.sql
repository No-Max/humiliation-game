--
-- PostgreSQL database dump
--

\restrict O87X5d6cIeQJKHghrM3QNpq8HYY6i2a3b392uoEL2BAXCc7lVSI0qba2H6kzurV

-- Dumped from database version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AdminRole; Type: TYPE; Schema: public; Owner: game
--

CREATE TYPE public."AdminRole" AS ENUM (
    'ADMIN',
    'EDITOR'
);


ALTER TYPE public."AdminRole" OWNER TO game;

--
-- Name: AnswerType; Type: TYPE; Schema: public; Owner: game
--

CREATE TYPE public."AnswerType" AS ENUM (
    'CHOICE',
    'TEXT'
);


ALTER TYPE public."AnswerType" OWNER TO game;

--
-- Name: QuestionContentType; Type: TYPE; Schema: public; Owner: game
--

CREATE TYPE public."QuestionContentType" AS ENUM (
    'IMAGE',
    'TEXT',
    'QUOTE',
    'LYRICS',
    'EMOJI',
    'IMAGE_TEXT'
);


ALTER TYPE public."QuestionContentType" OWNER TO game;

--
-- Name: RoomStatus; Type: TYPE; Schema: public; Owner: game
--

CREATE TYPE public."RoomStatus" AS ENUM (
    'WAITING',
    'PLAYING',
    'FINISHED'
);


ALTER TYPE public."RoomStatus" OWNER TO game;

--
-- Name: SeriesStatus; Type: TYPE; Schema: public; Owner: game
--

CREATE TYPE public."SeriesStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED'
);


ALTER TYPE public."SeriesStatus" OWNER TO game;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AdminUser; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."AdminUser" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."AdminRole" DEFAULT 'EDITOR'::public."AdminRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AdminUser" OWNER TO game;

--
-- Name: GameRoom; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."GameRoom" (
    id text NOT NULL,
    code text NOT NULL,
    "seriesId" text NOT NULL,
    status public."RoomStatus" DEFAULT 'WAITING'::public."RoomStatus" NOT NULL,
    "hostTeamId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."GameRoom" OWNER TO game;

--
-- Name: GameTeam; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."GameTeam" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "teamAccountId" text,
    name text NOT NULL,
    "logoUrl" text,
    score integer DEFAULT 0 NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    connected boolean DEFAULT false NOT NULL
);


ALTER TABLE public."GameTeam" OWNER TO game;

--
-- Name: MediaFile; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."MediaFile" (
    id text NOT NULL,
    filename text NOT NULL,
    path text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MediaFile" OWNER TO game;

--
-- Name: Question; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."Question" (
    id text NOT NULL,
    "tourId" text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "contentType" public."QuestionContentType" DEFAULT 'TEXT'::public."QuestionContentType" NOT NULL,
    prompt text,
    "mediaUrls" text[] DEFAULT ARRAY[]::text[],
    "answerType" public."AnswerType" DEFAULT 'TEXT'::public."AnswerType" NOT NULL,
    choices text[] DEFAULT ARRAY[]::text[],
    "correctAnswer" text NOT NULL,
    "acceptableAnswers" text[] DEFAULT ARRAY[]::text[],
    "timeLimitSec" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    hints text[] DEFAULT ARRAY[]::text[],
    points integer,
    "answerMedia" jsonb DEFAULT '[]'::jsonb NOT NULL
);


ALTER TABLE public."Question" OWNER TO game;

--
-- Name: Series; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."Series" (
    id text NOT NULL,
    title text NOT NULL,
    number integer NOT NULL,
    description text,
    "coverUrl" text,
    status public."SeriesStatus" DEFAULT 'DRAFT'::public."SeriesStatus" NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Series" OWNER TO game;

--
-- Name: SeriesTour; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."SeriesTour" (
    id text NOT NULL,
    "seriesId" text NOT NULL,
    "tourId" text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SeriesTour" OWNER TO game;

--
-- Name: TeamAccount; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."TeamAccount" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "logoUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TeamAccount" OWNER TO game;

--
-- Name: Tour; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public."Tour" (
    id text NOT NULL,
    title text NOT NULL,
    rules text,
    "defaultPoints" integer DEFAULT 3 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "defaultTimeLimitSec" integer DEFAULT 60 NOT NULL,
    "mediaUrls" text[] DEFAULT ARRAY[]::text[],
    "limitQuestionsToTeamCount" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Tour" OWNER TO game;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: game
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO game;

--
-- Data for Name: AdminUser; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."AdminUser" (id, email, "passwordHash", role, "createdAt", "updatedAt") FROM stdin;
cmssoikec000015yg2271dqxn	admin@game.local	$2a$10$qCRadY58eu.5y8GgpPnV8.ynVQ47pUzlirbGjH5TrEevhwXlFM1tW	ADMIN	2026-08-14 08:22:25.474	2026-08-14 08:22:25.474
cmssoikep000115ygn5pscoba	editor@game.local	$2a$10$//ICWDNDhaSLWvSy78Zgh.1v26AHA7C1pmFJP8XOjhB4Jq/0xPBYG	EDITOR	2026-08-14 08:22:25.489	2026-08-14 08:22:25.489
\.


--
-- Data for Name: GameRoom; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."GameRoom" (id, code, "seriesId", status, "hostTeamId", "createdAt", "updatedAt") FROM stdin;
cmssqfcsi000115gu63iflhch	v2crVxtb	cmssoikfv000715yghm3bbr6j	WAITING	cmssqfcsm000315gubivclqxi	2026-08-14 09:15:54.883	2026-08-14 09:15:54.889
cmssrqzx6000515gu5mjeu642	HUwssEAn	cmssoikfv000715yghm3bbr6j	WAITING	cmssrqzx9000715gu11dlqy7y	2026-08-14 09:52:57.69	2026-08-14 09:52:57.696
cmsstgt5c000d15gun7oyamg9	YKR3ewiU	cmssoikfv000715yghm3bbr6j	WAITING	cmsstgt5h000f15guyumwp89i	2026-08-14 10:41:01.585	2026-08-14 10:41:01.595
cmssx58jx000j15gubui23ttd	2BaVOPvZ	cmssoikfv000715yghm3bbr6j	WAITING	cmssx58k0000l15guqygyuiht	2026-08-14 12:24:00.142	2026-08-14 12:24:00.148
cmssxd7a2000n15gup40qpmdj	-aQSU-Gw	cmssoikfv000715yghm3bbr6j	WAITING	cmssxd7a5000p15guzz4206cb	2026-08-14 12:30:11.739	2026-08-14 12:30:11.743
cmssxehqn000r15gurj0ukn79	GW0us96N	cmssoikfv000715yghm3bbr6j	WAITING	cmssxehqo000t15guirdce7p9	2026-08-14 12:31:11.951	2026-08-14 12:31:11.953
cmswv2xyi000v15gurp2vvrs1	Lor1i8AX	cmssoikfv000715yghm3bbr6j	WAITING	cmswv2xym000x15guxj44vc18	2026-08-17 06:37:18.57	2026-08-17 06:37:18.577
cmsxbqj390008156ng4dtvh4z	vc0_m3v2	cmssoikfv000715yghm3bbr6j	WAITING	cmsxbqj3b000a156n8amizafa	2026-08-17 14:23:32.901	2026-08-17 14:23:32.907
cmsxdm5l1000t15pd9qmn2bqi	aL1FcjMA	cmssoikfv000715yghm3bbr6j	WAITING	cmsxdm5l3000v15pdk3uj4ffu	2026-08-17 15:16:08.005	2026-08-17 15:16:08.009
cmsxh6sz8000x15pdxeydqitm	CirwgHwc	cmssoikfv000715yghm3bbr6j	WAITING	cmsxh6szd000z15pdt8hqn1ow	2026-08-17 16:56:10.292	2026-08-17 16:56:10.3
cmsy9ap0k001015oc8vbhh5ns	jpZ6735Y	cmssoikfv000715yghm3bbr6j	WAITING	cmsy9ap0r001215oci4a07r3f	2026-08-18 06:03:01.028	2026-08-18 06:03:01.038
cmt16r8gb00071546nyb0bqlz	050MCR43	cmszsq4gm000a154zczpvlvhz	WAITING	cmt16r8gg000915461jmtn405	2026-08-20 07:15:12.395	2026-08-20 07:15:12.402
cmt1ng9pt000115vhbpe1iyfz	0zTF7ci1	cmssoikfv000715yghm3bbr6j	WAITING	cmt1ng9pv000315vhaj35lvy3	2026-08-20 15:02:34.289	2026-08-20 15:02:34.293
\.


--
-- Data for Name: GameTeam; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."GameTeam" (id, "roomId", "teamAccountId", name, "logoUrl", score, "sortOrder", connected) FROM stdin;
cmssqfcsm000315gubivclqxi	cmssqfcsi000115gu63iflhch	\N	Ирка	\N	0	0	f
cmssrqzx9000715gu11dlqy7y	cmssrqzx6000515gu5mjeu642	\N	Fa	\N	0	0	f
cmssrrqfz000915gu6li91glk	cmssrqzx6000515gu5mjeu642	\N	Pepe	\N	0	1	f
cmsstgt5h000f15guyumwp89i	cmsstgt5c000d15gun7oyamg9	\N	Пеппе	\N	0	0	f
cmssthf2m000h15gu1jhru1xl	cmsstgt5c000d15gun7oyamg9	\N	Я	\N	0	1	f
cmssx58k0000l15guqygyuiht	cmssx58jx000j15gubui23ttd	\N	Fa	\N	0	0	f
cmssxd7a5000p15guzz4206cb	cmssxd7a2000n15gup40qpmdj	\N	Fa	\N	0	0	f
cmssxehqo000t15guirdce7p9	cmssxehqn000r15gurj0ukn79	\N	Fa	\N	0	0	f
cmswv2xym000x15guxj44vc18	cmswv2xyi000v15gurp2vvrs1	\N	d	\N	0	0	f
cmsxbqj3b000a156n8amizafa	cmsxbqj390008156ng4dtvh4z	\N	Fa	\N	0	0	f
cmsxdm5l3000v15pdk3uj4ffu	cmsxdm5l1000t15pd9qmn2bqi	\N	Fa	\N	0	0	f
cmsxh6szd000z15pdt8hqn1ow	cmsxh6sz8000x15pdxeydqitm	\N	gege\\	\N	0	0	f
cmsy9ap0r001215oci4a07r3f	cmsy9ap0k001015oc8vbhh5ns	\N	Fa	\N	0	0	f
cmt16r8gg000915461jmtn405	cmt16r8gb00071546nyb0bqlz	\N	Fa	\N	0	0	f
cmt1ng9pv000315vhaj35lvy3	cmt1ng9pt000115vhbpe1iyfz	\N	Fa	\N	0	0	f
\.


--
-- Data for Name: MediaFile; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."MediaFile" (id, filename, path, "mimeType", size, "createdAt") FROM stdin;
cmswviu12000015il4rcy37mo	coke.webp	1786949379947-665889733.webp	image/webp	228238	2026-08-17 06:49:39.953
cmswviu3z000115iljb2186n6	logitech_k120_920-002522_0.jpg	1786949380074-280156890.jpg	image/jpeg	338828	2026-08-17 06:49:40.079
cmswvll9j000415il8g0deton	Screenshot From 2026-08-17 09-51-33.png	1786949508580-258086072.png	image/png	155312	2026-08-17 06:51:48.583
cmswwc0jt000515il838whhve	Screenshot From 2026-08-17 10-12-08.png	1786950741435-371255634.png	image/png	713234	2026-08-17 07:12:21.449
cmswx1g6m000915il7ey3ds4o	square_320_3cd0f2589a27aba9ab280406cdf9ad36.jpg	1786951928108-604397247.jpg	image/jpeg	84654	2026-08-17 07:32:08.111
cmsxbi3ug0002156nn3lvjo3b	Screenshot From 2026-08-17 17-16-46.png	1786976219886-441563728.png	image/png	253951	2026-08-17 14:16:59.896
cmsxbi3x90003156nx2ayvuag	Screenshot From 2026-08-17 17-16-28.png	1786976219992-190601311.png	image/png	315341	2026-08-17 14:16:59.997
cmsxbn2zb0004156nw57usqpj	britneyspears.webp	1786976452018-231467487.webp	image/webp	123278	2026-08-17 14:20:52.021
cmsxc7rns000015pdd2p9oiez	Screenshot From 2026-08-17 17-35-16.png	1786977417151-916910740.png	image/png	411445	2026-08-17 14:36:57.16
cmsxc967j000215pdndx59877	Screenshot From 2026-08-17 17-37-53.png	1786977482668-376066870.png	image/png	317776	2026-08-17 14:38:02.671
cmsxca9lm000315pdsu4qwiv5	thumb_8bab40e5b7472397164122a799aed6b8_380345.jpg	1786977533701-808368916.jpg	image/jpeg	38714	2026-08-17 14:38:53.703
cmsxcosit000615pdb4c7i8vt	Screenshot From 2026-08-17 17-49-56.png	1786978211381-497007598.png	image/png	273827	2026-08-17 14:50:11.391
cmsxcp4bu000915pdl2lsktey	Screenshot From 2026-08-17 17-49-42.png	1786978226728-157617808.png	image/png	156495	2026-08-17 14:50:26.73
cmsxcrc3v000a15pd3xlklsyq	nBkSUhL2h1Ihnc61JL6BrNOp2Z3z8Zj21iDEh_fH_nKUPXuaDyXTjHou4MVO6BCVoZKf9GqVe5Q_CPawk214LyWK9G1N5ho=RjOhk_g2042f3oW_8QQbpw.jpg	1786978330120-664873830.jpg	image/jpeg	28641	2026-08-17 14:52:10.123
cmsxcuj9x000d15pdqv6pfrf9	Screenshot From 2026-08-17 17-54-00.png	1786978479377-898358400.png	image/png	172313	2026-08-17 14:54:39.381
cmsxcujbo000e15pdhc8ck86i	Screenshot From 2026-08-17 17-53-39.png	1786978479441-657282969.png	image/png	168388	2026-08-17 14:54:39.445
cmsxcxxv9000f15pd6te5fc3h	347050627135795.webp	1786978638230-278310253.webp	image/webp	119848	2026-08-17 14:57:18.235
cmsxd4z4f000i15pdl50zre8j	366939.jpg	1786978966444-482030486.jpg	image/jpeg	97804	2026-08-17 15:02:46.448
cmsxd54r7000j15pdrttfzrbg	Screenshot From 2026-08-17 18-01-03.png	1786978973776-567965972.png	image/png	59353	2026-08-17 15:02:53.78
cmsxd54u1000k15pdf1ihxtko	Screenshot From 2026-08-17 18-00-54.png	1786978973878-894642468.png	image/png	138633	2026-08-17 15:02:53.881
cmsxdgkjr000n15pd7yvc6k3t	Screenshot From 2026-08-17 18-08-57.png	1786979507460-948113364.png	image/png	152100	2026-08-17 15:11:47.463
cmsxdgkl8000o15pdt5vy30gf	Screenshot From 2026-08-17 18-08-42.png	1786979507514-436808268.png	image/png	1161	2026-08-17 15:11:47.516
cmsxdltax000p15pd5xz4olth	Arnold_Schwarzenegger_-_2019_(33730956438)_(cropped).jpg	1786979752066-299103934.jpg	image/jpeg	30805	2026-08-17 15:15:52.068
cmsxjqy4x000015oc7v3fzuza	image.png	1786990069314-733115162.png	image/png	948765	2026-08-17 18:07:49.329
cmsxjse56000115ocean3zhn2	image.png	1786990136706-557843528.png	image/png	523348	2026-08-17 18:08:56.712
cmsxjvw01000215oc098u2x2e	image.png	1786990299835-83840847.png	image/png	353902	2026-08-17 18:11:39.841
cmsxjyjlv000515ocnvif8qpk	image.png	1786990423745-894973024.png	image/png	110916	2026-08-17 18:13:43.747
cmsxk7v4t000615ocgdazufz0	image.png	1786990858557-990210899.png	image/png	541636	2026-08-17 18:20:58.567
cmsxk9wlz000715oc0eoukst3	image.png	1786990953789-322230693.png	image/png	614254	2026-08-17 18:22:33.811
cmsxkdilo000a15ocuyd1nrxp	image.png	1786991122254-610523555.png	image/png	286288	2026-08-17 18:25:22.274
cmsxkgxz7000b15ocsk5g9cds	image.png	1786991282135-117148039.png	image/png	580827	2026-08-17 18:28:02.144
cmsxkhe6h000c15ocrx2b9tcf	image.png	1786991303175-167217682.png	image/png	189435	2026-08-17 18:28:23.177
cmsxkqnn2000f15ocu1leynui	image.png	1786991735290-104830868.png	image/png	903493	2026-08-17 18:35:35.306
cmsxksxd2000g15oc5kqhtjys	image.png	1786991841237-842618674.png	image/png	944094	2026-08-17 18:37:21.253
cmsxkxxxg000h15ocidksmj4a	image.png	1786992075233-505050483.png	image/png	750730	2026-08-17 18:41:15.242
cmsxlq9qh000k15ocphvzno2j	image.png	1786993396862-714799303.png	image/png	838212	2026-08-17 19:03:16.896
cmsxlun8l000l15oce4etv3zd	image.png	1786993601054-59882149.png	image/png	948503	2026-08-17 19:06:41.061
cmsxly5gi000m15ocfc09286i	image.png	1786993764616-131939400.png	image/png	275021	2026-08-17 19:09:24.621
cmsxmv9mk000p15oc77hl0wvh	image.png	1786995309677-637794118.png	image/png	690711	2026-08-17 19:35:09.692
cmsxmxn5z000q15oc2ogd85yh	image.png	1786995420535-771351153.png	image/png	588257	2026-08-17 19:37:00.55
cmsxn1m8z000r15ocfokyjnts	image.png	1786995605947-558136332.png	image/png	263768	2026-08-17 19:40:05.954
cmsxoa67l000w15ocvoeeguxz	image.png	1786997684682-514144866.png	image/png	665736	2026-08-17 20:14:44.691
cmsy9tc04001515ocom6l2xyr	image.png	1787033850617-596405364.png	image/png	334622	2026-08-18 06:17:30.627
cmsy9wsxs001615occqov1fpb	image.png	1787034012536-363430577.png	image/png	494319	2026-08-18 06:20:12.544
cmsy9x4ps001715ocmkp6cmhh	image.png	1787034027804-261937277.png	image/png	503228	2026-08-18 06:20:27.808
cmsya8knm001815oc63co8uec	image.png	1787034561680-486862698.png	image/png	134471	2026-08-18 06:29:21.683
cmsya9wcb001915ocqew3ol9j	image.png	1787034623477-654645772.png	image/png	145444	2026-08-18 06:30:23.481
cmsyah1os001d15ocw1wbjpy7	image.png	1787034956997-166413380.png	image/png	458136	2026-08-18 06:35:57.005
cmsyk8q35001h15ocqyt14bue	image.png	1787051364877-169592643.png	image/png	480995	2026-08-18 11:09:24.881
cmsykh96a001l15ocl5zdm2c9	image.png	1787051762858-495414781.png	image/png	449894	2026-08-18 11:16:02.867
cmsyo56jv001o15ocmwx7g7ae	image.png	1787057918052-309092604.png	image/png	143366	2026-08-18 12:58:38.057
cmsyoc1g7001p15ocmp49jr2m	image.png	1787058238034-676837140.png	image/png	548748	2026-08-18 13:03:58.039
cmsyoh5a6001q15ocs7kw69f9	image.png	1787058476279-843580627.png	image/png	367079	2026-08-18 13:07:56.285
cmsyoib5o001t15ocpvmt6gbb	image.png	1787058530520-471253980.png	image/png	28260	2026-08-18 13:08:50.522
cmsyol45o001u15ocet96mpuf	image.png	1787058661450-292351723.png	image/png	128277	2026-08-18 13:11:01.452
cmsyp14bz001x15oct4pvouop	image.png	1787059408173-435538273.png	image/png	152285	2026-08-18 13:23:28.175
cmsyp2h9c001y15ocq9yjb93i	image.png	1787059471581-696713766.png	image/png	161550	2026-08-18 13:24:31.584
cmsysf0vk000015ie5rpto4mu	image.png	1787065095719-895451707.png	image/png	229273	2026-08-18 14:58:15.728
cmsysfaji000115ie0bwycl3b	image.png	1787065108250-454530265.png	image/png	227560	2026-08-18 14:58:28.254
cmsysr22o000415ie57gm3vj2	image.png	1787065657148-887051607.png	image/png	95495	2026-08-18 15:07:37.153
cmsysrum5000515ienn162s46	image.png	1787065694131-244918508.png	image/png	605686	2026-08-18 15:08:14.14
cmsysu7gx000615ie56qisesz	image.png	1787065804109-19357688.png	image/png	219835	2026-08-18 15:10:04.112
cmsyt1bg8000915ie854d35pv	image.png	1787066135862-806399207.png	image/png	133630	2026-08-18 15:15:35.864
cmsyt27rr000a15ieozehe4du	image.png	1787066177747-263357537.png	image/png	623711	2026-08-18 15:16:17.751
cmszsrfpz000d154zrqy3korq	image.png	1787126141001-46741484.png	image/png	516709	2026-08-19 07:55:41.015
cmszstduk000e154zp114yk43	image.png	1787126231878-680272020.png	image/png	892253	2026-08-19 07:57:11.893
cmszsxvpw000i154zd2zi4n4i	image.png	1787126441681-674902047.png	image/png	209406	2026-08-19 08:00:41.684
cmszsy9h7000j154z2ot029qp	image.png	1787126459509-456717975.png	image/png	244493	2026-08-19 08:00:59.514
cmszt1csf000m154z9sxs3js1	image.png	1787126603770-45713692.png	image/png	216663	2026-08-19 08:03:23.775
cmszt21z7000n154zhh0hvxr7	image.png	1787126636410-561664428.png	image/png	572219	2026-08-19 08:03:56.419
cmszt7lug000q154zto1t8xvo	image.png	1787126895445-430354854.png	image/png	315164	2026-08-19 08:08:15.448
cmsztdtph000r154zs6zzvlu0	image.png	1787127185556-50046270.png	image/png	581106	2026-08-19 08:13:05.572
cmszth5ye000v154zeh9tuy2z	image.png	1787127341411-789379351.png	image/png	215004	2026-08-19 08:15:41.414
cmszthiy9000w154z7lf77i6x	image.png	1787127358254-340257561.png	image/png	227819	2026-08-19 08:15:58.257
cmsztrz550010154zry6vgbo4	image.png	1787127845798-261457765.png	image/png	318297	2026-08-19 08:24:05.801
cmsztskum0011154zs3zvfdvv	image.png	1787127873931-593010527.png	image/png	315472	2026-08-19 08:24:33.934
cmsztyj4u0014154zzrr95ovw	image.png	1787128151639-231361545.png	image/png	401570	2026-08-19 08:29:11.645
cmsztz0nz0015154ztpvmmw3c	image.png	1787128174362-165468711.png	image/png	464514	2026-08-19 08:29:34.366
cmszu5uby0019154z4xrn6kxk	image.png	1787128492747-21867250.png	image/png	268867	2026-08-19 08:34:52.751
cmszu7hcq001a154zd7tggi7p	image.png	1787128569239-539799500.png	image/png	342237	2026-08-19 08:36:09.242
cmszuf5v4001e154ztcc2ieo0	image.png	1787128927597-87061277.png	image/png	346996	2026-08-19 08:42:07.601
cmszui0nn001f154zqdkablpf	image.png	1787129060811-450850934.png	image/png	376789	2026-08-19 08:44:20.818
cmszuk70b001i154zev1pm8rk	image.png	1787129162350-206112688.png	image/png	526118	2026-08-19 08:46:02.364
cmszukvul001j154z3movopu8	image.png	1787129194555-112554673.png	image/png	161059	2026-08-19 08:46:34.557
cmszuq19y001m154zcxst3zy7	image.png	1787129434867-363554229.png	image/png	170275	2026-08-19 08:50:34.871
cmszurbm5001n154z89q8kxhr	image.png	1787129494920-407817450.png	image/png	362731	2026-08-19 08:51:34.924
cmszutnt1001q154zlnievqjk	image.png	1787129604033-130009929.png	image/png	472159	2026-08-19 08:53:24.037
cmszux0h0001r154zzvxoqb1r	image.png	1787129760390-166553920.png	image/png	354374	2026-08-19 08:56:00.393
cmt0379m6000d15lroiy7womp	image.png	1787143675751-683070903.png	image/png	626600	2026-08-19 12:47:55.759
cmt04bxrq000g15lryps16zer	image.png	1787145573270-64912332.png	image/png	91363	2026-08-19 13:19:33.276
cmt04eejf000j15lr8g1fwwma	image.png	1787145688344-760914162.png	image/png	116585	2026-08-19 13:21:28.347
cmt06dk2n000k15lr4fyqvgl5	image.png	1787149008051-406872408.png	image/png	579737	2026-08-19 14:16:48.068
cmt07g45m000a15b9js9nfvup	image.png	1787150807048-204500661.png	image/png	66878	2026-08-19 14:46:47.051
cmt07m27r000d15b98pzcvi7s	image.png	1787151084462-555768116.png	image/png	156723	2026-08-19 14:51:24.469
cmt07uebh000g15b9vsz78mch	image.png	1787151473346-298957215.png	image/png	195607	2026-08-19 14:57:53.357
cmt0838j4000j15b9ta2fw089	image.png	1787151885763-320936341.png	image/png	223135	2026-08-19 15:04:45.773
cmt08sl8i000m15b9yd77xum7	image.png	1787153068642-938527344.png	image/png	20290	2026-08-19 15:24:28.646
cmt13th2a000p15b9rjkbr7o2	image.png	1787205178015-27318170.png	image/png	81920	2026-08-20 05:52:58.018
cmt1613x6000015465hiudgyw	[Blogway] ÐÑÑÐº Ð¦ÑÐ¿ÐµÑ â ÐÑÐ¼Ð¾Ðº (feat. ÐÐ³Ð¾ÑÑ Ð¦ÑÐ±Ð°) (mp3cut.net).mp3	1787208893458-384127665.mp3	audio/mpeg	215563	2026-08-20 06:54:53.466
cmt1663hf00011546nhvg42qn	[Blogway] ÐÑÑÐº Ð¦ÑÐ¿ÐµÑ â ÐÑÐ¼Ð¾Ðº (feat. ÐÐ³Ð¾ÑÑ Ð¦ÑÐ±Ð°) (mp3cut.net) (1).mp3	1787209126175-423972368.mp3	audio/mpeg	221707	2026-08-20 06:58:46.179
cmt167n7600021546el14op2x	[Blogway] ÐÑÑÐº Ð¦ÑÐ¿ÐµÑ â ÐÑÐ¼Ð¾Ðº (feat. ÐÐ³Ð¾ÑÑ Ð¦ÑÐ±Ð°) (mp3cut.net).mp3	1787209198382-5459798.mp3	audio/mpeg	221707	2026-08-20 06:59:58.386
cmt16ghmq00031546rzk8bvs8	[Blogway] ÐÑÑÐº Ð¦ÑÐ¿ÐµÑ â ÐÑÐ¼Ð¾Ðº (feat. ÐÐ³Ð¾ÑÑ Ð¦ÑÐ±Ð°) (mp3cut.net).mp3	1787209611043-222049783.mp3	audio/mpeg	217099	2026-08-20 07:06:51.048
cmt16lr7900041546a2uc82p7	[Blogway] ÐÑÑÐº Ð¦ÑÐ¿ÐµÑ â ÐÑÐ¼Ð¾Ðº (feat. ÐÐ³Ð¾ÑÑ Ð¦ÑÐ±Ð°) (mp3cut.net).mp3	1787209856750-163328550.mp3	audio/mpeg	217099	2026-08-20 07:10:56.757
cmt16q9rr0005154689z8xmky	[Blogway] ÐÑÑÐº Ð¦ÑÐ¿ÐµÑ â ÐÑÐ¼Ð¾Ðº (feat. ÐÐ³Ð¾ÑÑ Ð¦ÑÐ±Ð°) (mp3cut.net) (1).mp3	1787210067443-268006400.mp3	audio/mpeg	229771	2026-08-20 07:14:27.447
cmt19etww000a15463sqzz1bi	Icyk_Cyper_Igor_cyba_-_Nefertiti_muzob (mp3cut.net).mp3	1787214572523-342771308.mp3	audio/mpeg	337546	2026-08-20 08:29:32.528
cmt19koja000b1546bqusv9zf	Icyk_Cyper_Igor_cyba_-_Nefertiti_muzob (mp3cut.net).mp3	1787214845471-785326476.mp3	audio/mpeg	325008	2026-08-20 08:34:05.487
cmt19lv6s000c1546cp8kb4ik	Icyk_Cyper_Igor_cyba_-_Nefertiti_muzob (mp3cut.net).mp3	1787214900769-626903388.mp3	audio/mpeg	331277	2026-08-20 08:35:00.772
cmt19rsap000d1546dceaobhy	Icyk_Cyper_Igor_cyba_-_Piterskij_glamur_(SkySound7 (mp3cut.net).mp3	1787215176952-393998799.mp3	audio/mpeg	546526	2026-08-20 08:39:36.96
cmt1b8jac000e15469b7mpggr	Icyk_Cyper_Igor_cyba_-_Piterskij_glamur_(SkySound7 (mp3cut.net) (1).mp3	1787217638006-225561201.mp3	audio/mpeg	644746	2026-08-20 09:20:38.019
cmt1ba9wj000f1546gmlvwucl	Icyk_Cyper_Igor_cyba_-_Piterskij_glamur_(SkySound7 (mp3cut.net) (2).mp3	1787217719197-558420186.mp3	audio/mpeg	669824	2026-08-20 09:21:59.203
cmt1bbw2j000g154636vlkw68	image.png	1787217794582-51131738.png	image/png	366719	2026-08-20 09:23:14.588
\.


--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."Question" (id, "tourId", "sortOrder", "contentType", prompt, "mediaUrls", "answerType", choices, "correctAnswer", "acceptableAnswers", "timeLimitSec", "createdAt", "updatedAt", hints, points, "answerMedia") FROM stdin;
cmsxccxco000515pda0h8b104	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Фамилия Певца	{/uploads/1786977482668-376066870.png,/uploads/1786977451894-924022945.png}	TEXT	{}	Кирка + Корка = Киркоров	{"Филип Киркоров",Киркоров,Kirkorov,"Филипп Киркоров"}	\N	2026-08-17 14:40:57.816	2026-08-20 15:06:00.795	{"Один из мужей Пугачевой"}	\N	[{"url": "/uploads/1786977482668-376066870.png", "type": "IMAGE"}, {"url": "/uploads/1786977417151-916910740.png", "type": "IMAGE"}, {"url": "/uploads/1786977533701-808368916.jpg", "type": "IMAGE"}]
cmsxbqaab0006156n7bugcnhg	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Селебрити (в ответ написать имя и фамилию)	{/uploads/1786976219992-190601311.png,/uploads/1786976219886-441563728.png}	TEXT	{}	Бритый + Пирс = Бритни Спирс	{"britney spears","britney speers","britny spears","britny speers","Бритни Спирс"}	\N	2026-08-17 14:23:21.489	2026-08-20 15:04:50.771	{"Американская поп-певица",Блондинка}	\N	[{"url": "/uploads/1786976219992-190601311.png", "type": "IMAGE"}, {"url": "/uploads/1786976219886-441563728.png", "type": "IMAGE"}, {"url": "/uploads/1786976452018-231467487.webp", "type": "IMAGE"}]
cmszusgry001p154ztql4kjlg	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>На что косплей?</p>	{/uploads/1787129434867-363554229.png}	TEXT	{}	Оскар	{"Примия оскар",оскор}	\N	2026-08-19 08:52:28.269	2026-08-19 08:52:28.269	{Премия}	\N	[{"url": "/uploads/1787129494920-407817450.png", "type": "IMAGE"}]
cmsxcrge9000c15pd1ptasuaz	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Псевдоним Певицы (в ответ напишите 2 слова)	{/uploads/1786978226728-157617808.png,/uploads/1786978211381-497007598.png}	TEXT	{}	Клавиатура (Клава) + Кокан  = Клава Кока	{"Клава Кока",Клава-Кока,"Klava Coca","Klava Koka"}	\N	2026-08-17 14:52:15.681	2026-08-20 15:10:16.853	{"Русская певица","Кла́вдия Высо́кова"}	\N	[{"url": "/uploads/1786978330120-664873830.jpg", "type": "IMAGE"}, {"url": "/uploads/1786978226728-157617808.png", "type": "IMAGE"}, {"url": "/uploads/1786978211381-497007598.png", "type": "IMAGE"}]
cmsxcyn2k000h15pdfbxvwrpq	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Фамилия Актера	{/uploads/1786978479441-657282969.png,/uploads/1786978479377-898358400.png}	TEXT	{}	Кол + Грива = Кологривый	{"Никаита Кологривый",Калогривый,Кологривый,Kologrivyy}	\N	2026-08-17 14:57:50.924	2026-08-20 15:13:19.029	{"Русский актер",Пацан}	\N	[{"url": "/uploads/1786978479441-657282969.png", "type": "IMAGE"}, {"url": "/uploads/1786978479377-898358400.png", "type": "IMAGE"}, {"url": "/uploads/1786978638230-278310253.webp", "type": "IMAGE"}]
cmsxjw8wb000415ocu6q60h5g	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Имя и фамилия актера	{/uploads/1786990136706-557843528.png,/uploads/1786990069314-733115162.png}	TEXT	{}	VIN + Дизель = Вин Дизель	{"Вин Дизель","Vin Disel","Vin Diesel"}	\N	2026-08-17 18:11:56.555	2026-08-20 15:14:16.51	{Форсаж}	\N	[{"url": "/uploads/1786990136706-557843528.png", "type": "IMAGE"}, {"url": "/uploads/1786990069314-733115162.png", "type": "IMAGE"}, {"url": "/uploads/1786990299835-83840847.png", "type": "IMAGE"}]
cmsxkbscd000915oc0037d66y	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Имя и фамилия актера	{/uploads/1786990423745-894973024.png,/uploads/1786990858557-990210899.png}	TEXT	{}	Том (книжный) + Холод = Том Холланд	{"Том Холланд","Tom Holland","Том Холанд","Тот Холонд"}	\N	2026-08-17 18:24:01.59	2026-08-20 15:15:34.456	{Паук}	\N	[{"url": "/uploads/1786990423745-894973024.png", "type": "IMAGE"}, {"url": "/uploads/1786990858557-990210899.png", "type": "IMAGE"}, {"url": "/uploads/1786990953789-322230693.png", "type": "IMAGE"}]
cmsxkj95f000e15ock3sqejnj	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Имя и фамилия актера	{/uploads/1786991282135-117148039.png,/uploads/1786991303175-167217682.png}	TEXT	{}	Команда (Team) + Рот = Тим Рот	{"Тим Рот","Tim Rot","Tim Roth"}	\N	2026-08-17 18:29:49.971	2026-08-20 15:16:11.345	{"Обмани меня"}	\N	[{"url": "/uploads/1786991282135-117148039.png", "type": "IMAGE"}, {"url": "/uploads/1786991303175-167217682.png", "type": "IMAGE"}, {"url": "/uploads/1786991122254-610523555.png", "type": "IMAGE"}]
cmsxl1tua000j15ocmkbi7hmy	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Имя и фамилия актера	{/uploads/1786991735290-104830868.png,/uploads/1786991841237-842618674.png}	TEXT	{}	Жим + Кари = Джим Керри	{"Джим Керри","Jim Carry","Джим Кери"}	\N	2026-08-17 18:44:16.592	2026-08-20 15:17:12.87	{Вентура}	\N	[{"url": "/uploads/1786991735290-104830868.png", "type": "IMAGE"}, {"url": "/uploads/1786991841237-842618674.png", "type": "IMAGE"}, {"url": "/uploads/1786992075233-505050483.png", "type": "IMAGE"}]
cmsxm3t7k000o15oc0it2gauu	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Имя и фамилия актера	{/uploads/1786993601054-59882149.png,/uploads/1786993396862-714799303.png}	TEXT	{}	Альпы + Чинит  = Аль Пачино	{"Аль Пачино","Al Pacino"}	\N	2026-08-17 19:13:48.704	2026-08-20 15:17:52.575	{Шрам,Лицо}	\N	[{"url": "/uploads/1786993601054-59882149.png", "type": "IMAGE"}, {"url": "/uploads/1786993396862-714799303.png", "type": "IMAGE"}, {"url": "/uploads/1786993764616-131939400.png", "type": "IMAGE"}]
cmssoikev000315yg693gk3h8	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Куда он идет?	{/uploads/1787033823136-802736792.png}	TEXT	{}	К реке	{"Идущий к реке",реке,река}	\N	2026-08-14 08:22:25.495	2026-08-18 06:18:45.472	{"Он уже понял эту жизнь"}	\N	[{"url": "/uploads/1787033850617-596405364.png", "type": "IMAGE"}]
cmsxoc5b5000y15ock6vx7f04	cmswxaf6m000a15ilhslj3ut3	0	TEXT	Сколько раз повторяется слово «видно» в песне «Ветер с моря дул» в исполнении Натали?	{}	CHOICE	{24,27,30,33}	27	{}	\N	2026-08-17 20:16:16.863	2026-08-17 20:16:16.863	{}	\N	[{"url": "/uploads/1786997684682-514144866.png", "type": "IMAGE"}]
cmssoikev000415yg9zkorumf	cmssoikev000215ygpblgocrv	1	IMAGE_TEXT	Что показывает Боромир?	{/uploads/1787034012536-363430577.png}	TEXT	{}	Всевидящее око или просто око	{"Всевидящее око","Всевидящий глаз",око,глаз}	\N	2026-08-14 08:22:25.495	2026-08-18 06:29:15.884	{"Башня в Мордоре"}	\N	[{"url": "/uploads/1787034027804-261937277.png", "type": "IMAGE"}]
cmsyab3w8001b15occfqv0xp1	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Назовите скрытое имя	{/uploads/1787034623477-654645772.png}	TEXT	{}	Миша	{Михаил,Мишаня,Миха}	\N	2026-08-18 06:31:19.926	2026-08-18 06:31:19.926	{Медведь}	\N	[{"url": "/uploads/1787034561680-486862698.png", "type": "IMAGE"}]
cmsyked2a001j15octpnpclhg	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Назовите фильм	{/uploads/1787051364877-169592643.png}	TEXT	{}	Остров проклятых	{"Остров проклятых","Shutter Island"}	\N	2026-08-18 11:13:47.919	2026-08-18 11:13:47.919	{}	\N	[{"url": "/uploads/1787051346575-549427833.png", "type": "IMAGE"}]
cmsyt3b18000c15iepsh3egw7	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	<p>Назовите сериал</p>	{/uploads/1787066135862-806399207.png}	TEXT	{}	Настоящий детектив	{"True detective"}	\N	2026-08-18 15:17:08.634	2026-08-18 15:17:08.634	{Детектив}	\N	[{"url": "/uploads/1787066177747-263357537.png", "type": "IMAGE"}]
cmsyklouo001n15oc257cmikl	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Назовите его фамилию	{/uploads/1787051759408-917433968.png}	TEXT	{}	Понасенков	{Понасенков,Поносенков,Панасенков,Паносенков,Ponasenkov}	\N	2026-08-18 11:19:29.783	2026-08-18 12:57:14.657	{Понес}	\N	[{"url": "/uploads/1787051762858-495414781.png", "type": "IMAGE"}]
cmsyahkl6001f15ocivknl78y	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Сколько?	{/uploads/1787034949591-183071997.png}	TEXT	{}	На донышке	{}	\N	2026-08-18 06:36:21.498	2026-08-18 12:58:47.5	{"В стакане"}	\N	[{"url": "/uploads/1787057918052-309092604.png", "type": "IMAGE"}]
cmsyoh9t6001s15oc2oculqdp	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Назвать вид лисы	{/uploads/1787058238034-676837140.png}	TEXT	{}	Упоротый лис	{"Упоротый лис",Упоротый,Упоротая,Упоратый,Упоролся,Упоротость,Упоратая}	\N	2026-08-18 13:08:02.154	2026-08-18 13:08:02.154	{}	\N	[{"url": "/uploads/1787058476279-843580627.png", "type": "IMAGE"}]
cmsyomf9b001w15occwlywdyn	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Насколько сильно?	{/uploads/1787058530520-471253980.png}	TEXT	{}	Полностью	{Полнастью,Полностью}	\N	2026-08-18 13:12:02.495	2026-08-18 13:12:02.495	{Ломай}	\N	[{"url": "/uploads/1787058661450-292351723.png", "type": "IMAGE"}]
cmsyqu4xp002015ocvh0jjc15	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	Какой вопрос скрыт?	{/uploads/1787059408173-435538273.png}	TEXT	{}	Совпадение?	{Совпадение,Сопадение,Совпадение?}	\N	2026-08-18 14:14:01.561	2026-08-18 14:14:01.561	{"Одно слово"}	\N	[{"url": "/uploads/1787059471581-696713766.png", "type": "IMAGE"}]
cmsysowyn000315iestoh5jeo	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	<p>Какое слово скрыто? (напишите в ответ фонетически точное слово)</p>	{/uploads/1787065095719-895451707.png}	TEXT	{}	Узбагойся	{Узбагойся!}	\N	2026-08-18 15:05:57.188	2026-08-18 15:05:57.188	{Успокойся}	\N	[{"url": "/uploads/1787065108250-454530265.png", "type": "IMAGE"}]
cmsysuzet000815ierxl1arvw	cmssoikev000215ygpblgocrv	0	IMAGE_TEXT	<p>Напишите в ответ имя или фамилию этого парня</p>	{/uploads/1787065694131-244918508.png}	TEXT	{}	Сашко Фокин	{Сашко,Фокин,Саша,Александр,"Саша Фокин"}	\N	2026-08-18 15:10:40.325	2026-08-18 15:10:40.325	{"Я сейчас буду устанавливать все игры"}	\N	[{"url": "/uploads/1787065804109-19357688.png", "type": "IMAGE"}]
cmsxdbm8o000m15pdrmapzvf2	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Имя и фамилия актрисы	{/uploads/1786978973878-894642468.png,/uploads/1786978973776-567965972.png}	TEXT	{}	Мерить + Стрип = Мэрил Стрип	{"Мэрил Стрип","Мерил Стрип","Мэри Стрип","Meryl Streep","Merryl Strip","Mery Streep"}	\N	2026-08-17 15:07:56.351	2026-08-20 15:02:18.22	{"Трёхкратная обладательница премии «Оскар»"}	\N	[{"url": "/uploads/1786978973878-894642468.png", "type": "IMAGE"}, {"url": "/uploads/1786978973776-567965972.png", "type": "IMAGE"}, {"url": "/uploads/1786978966444-482030486.jpg", "type": "IMAGE"}]
cmsxn5nq6000t15ocpvjtj66n	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	Имя и фамилия актера	{/uploads/1786995309677-637794118.png,/uploads/1786995420535-771351153.png}	TEXT	{}	Бренд + Пита = Бред Питт	{"Brad Pitt","Бред Питт","Бред Пит","Брэд Питт","Брэд Пит"}	\N	2026-08-17 19:43:14.525	2026-08-20 15:18:38.032	{"Джо Блэк"}	\N	[{"url": "/uploads/1786995309677-637794118.png", "type": "IMAGE"}, {"url": "/uploads/1786995420535-771351153.png", "type": "IMAGE"}, {"url": "/uploads/1786995605947-558136332.png", "type": "IMAGE"}]
cmsxdlv02000r15pdamvm8p6s	cmswviw3x000215ilrypyhnqw	0	IMAGE_TEXT	<p>Фамиля политика</p>	{/uploads/1786979507514-436808268.png,/uploads/1786979507460-948113364.png}	TEXT	{}	Шварц (немецкий) + "Негр" = Шварценеггер	{Шварценеггер,Шварценегер,Шварцениггер,Шварценигер,"Arnold Schwarzenegger",Schwarzenegger,Schwarzeneger,"Арнольд Шварценеггер","Арнольд Шварценегер",шварцнегер,Шварцнеггер}	\N	2026-08-17 15:15:54.29	2026-08-20 15:12:04.085	{"Американский политик","Австрийского происхождения"}	\N	[{"url": "/uploads/1786979507514-436808268.png", "type": "IMAGE"}, {"url": "/uploads/1786979507460-948113364.png", "type": "IMAGE"}, {"url": "/uploads/1786979752066-299103934.jpg", "type": "IMAGE"}]
cmszsvyuy000g154zchz4ius4	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Как зовут персонажа?</p>	{/uploads/1787126141001-46741484.png}	TEXT	{}	Аквамэн	{Аквомэн,"Аква мэн","Акво мэн",Aquaman}	\N	2026-08-19 07:59:12.441	2026-08-19 07:59:12.441	{"Зарубежный родственник водяного"}	\N	[{"url": "/uploads/1787126231878-680272020.png", "type": "IMAGE"}]
cmszt0t3i000l154z1q3305vp	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Имя персонажа</p>	{/uploads/1787126424281-935679548.png}	TEXT	{}	Лилу из Пятого элемента	{Лилу}	\N	2026-08-19 08:02:58.254	2026-08-19 08:02:58.254	{"Мила Йовович"}	\N	[{"url": "/uploads/1787126441681-674902047.png", "type": "IMAGE"}, {"url": "/uploads/1787126459509-456717975.png", "type": "IMAGE"}]
cmszt4ldj000p154z3347vucp	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Имя и фамилия персонажа</p>	{/uploads/1787126603770-45713692.png}	TEXT	{}	Баз Лайтер из Истории Игрушек	{"Баз Лайтер","Баз Лайтэр","Buzz Lightyear","Buz Lightyear","Базз Лайтер"}	\N	2026-08-19 08:05:54.869	2026-08-19 08:05:54.869	{"История игрушек"}	\N	[{"url": "/uploads/1787126636410-561664428.png", "type": "IMAGE"}]
cmsztek4v000t154zo8aydqx2	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Ответьте двумя словами, на что косплей?</p>	{/uploads/1787126895445-430354854.png}	TEXT	{}	Око Саурона	{"Око Саурона","Всевидящее око","Всевидящее Око Саурона","Глаз саурона","Всевидящий глаз","Всевидящий глаз Саурона"}	\N	2026-08-19 08:13:39.791	2026-08-19 08:13:39.791	{"Властелин колец"}	\N	[{"url": "/uploads/1787127185556-50046270.png", "type": "IMAGE"}]
cmsztkgib000y154z59riptv0	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Назовите персонажа одним словом</p>	{/uploads/1787127318398-741486312.png}	TEXT	{}	Покемон Бульбазавр	{Бульбазавр,Бульбозавр,Бульбазаур,Bulbasaur}	\N	2026-08-19 08:18:15.057	2026-08-19 08:18:15.057	{Покемон}	\N	[{"url": "/uploads/1787127341411-789379351.png", "type": "IMAGE"}, {"url": "/uploads/1787127358254-340257561.png", "type": "IMAGE"}]
cmsztuypx0013154z43z5m9tq	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Назови персонажа</p>	{/uploads/1787127599040-737323751.png}	TEXT	{}	Росомаха	{росомаха,расомаха,россомаха,росамаха,расамаха,рассамаха,Wolverine}	\N	2026-08-19 08:26:25.198	2026-08-19 08:26:25.198	{Марвел}	\N	[{"url": "/uploads/1787127845798-261457765.png", "type": "IMAGE"}, {"url": "/uploads/1787127873931-593010527.png", "type": "IMAGE"}]
cmszu2b780017154zvjcxrg4n	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Как зовут персонажа</p>	{/uploads/1787128151639-231361545.png}	TEXT	{}	Чудо женщина	{"Wonder Woman",Чудо-женщина,"женщина Чудо"}	\N	2026-08-19 08:32:07.958	2026-08-19 08:32:07.958	{DC}	\N	[{"url": "/uploads/1787128174362-165468711.png", "type": "IMAGE"}]
cmszuc06g001c154z5150kf28	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Как зовут персонажа?</p>	{/uploads/1787128489258-697094019.png}	TEXT	{}	Джон Кра́мер или Констру́ктор	{Конструктор,"Джон Крамер",Крамер,"John Kramer",Kramer}	\N	2026-08-19 08:39:40.239	2026-08-19 08:39:40.239	{Пила,Лего}	\N	[{"url": "/uploads/1787128492747-21867250.png", "type": "IMAGE"}, {"url": "/uploads/1787128569239-539799500.png", "type": "IMAGE"}]
cmszujauo001h154z0tesnb54	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Назовите персонажа</p>	{/uploads/1787128925626-945386796.png}	TEXT	{}	Кхал Дрого из Игры престолов	{"Khal Drogo","кхал дрого",Кхал,дрого,Drogo,Khal}	\N	2026-08-19 08:45:20.686	2026-08-19 08:45:20.686	{}	\N	[{"url": "/uploads/1787128927597-87061277.png", "type": "IMAGE"}, {"url": "/uploads/1787129060811-450850934.png", "type": "IMAGE"}]
cmszupwr1001l154z6v72cng8	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Назови персонажа</p>	{/uploads/1787129194555-112554673.png}	TEXT	{}	Белоснежка	{}	\N	2026-08-19 08:50:28.97	2026-08-19 08:50:28.97	{Гномы}	\N	[{"url": "/uploads/1787129162350-206112688.png", "type": "IMAGE"}]
cmszuzopo001v154zjmx6rua7	cmsy9qrl9001315octvt4vhd0	0	IMAGE_TEXT	<p>Персонаж</p>	{/uploads/1787129779986-140246536.png}	TEXT	{}	Дарт Вейдер	{"Darth Vader","Дарт Вэйдер","Дарт Вэйдэр","Дарт Вейдр","Дарт Вэйдр"}	\N	2026-08-19 08:58:05.147	2026-08-19 08:58:05.147	{}	\N	[{"url": "/uploads/1787129760390-166553920.png", "type": "IMAGE"}, {"url": "/uploads/1787129782219-872292501.png", "type": "IMAGE"}]
cmsstf4lg000b15gu8of0gxgh	cmssoikfm000515ygpnppss36	4	TEXT	<p>Закончите отрывок песни “Дымок” Ицык цыпера (Игорь Цыба):</p><p><em>Курнули снова ручничок</em></p><p><em>С него поймали шугничок&nbsp;</em></p><p><em>Опять прогнали паровоз&nbsp;</em></p><p><em>Прибило, сука, ….</em></p>	{}	CHOICE	{"аж подрос","aж понос","аж мороз","аж до слёз"}	аж до слёз	{}	\N	2026-08-14 10:39:43.108	2026-08-20 07:11:05.213	{}	\N	[{"url": "/uploads/1787209856750-163328550.mp3", "type": "AUDIO"}]
cmt03id3a000f15lr1kg4pk5e	cmsx0qahb000d15ilb2pmn2mq	0	TEXT	<p>Ответьте одним словом:</p><p><em>Лежит на спине — никому не нужна. Прислони к стене — пригодится она.</em></p>	{}	TEXT	{}	Лестница	{Стремянка}	\N	2026-08-19 12:56:33.453	2026-08-20 06:25:08.416	{"1 Помогает подняться выше"}	\N	[{"url": "/uploads/1787145688344-760914162.png", "type": "IMAGE"}]
cmt07nkcr000f15b9zgln43ea	cmswzuzqz000c15ilh01n5rxq	0	TEXT	<p>Закончите утойчивым выражением из 2х слов:</p><p><em>Саша уронил карандаш и не может до него дотянуться, его сосед по парте Леша попробовал достать ногой, но тоже не смог, поэтому Леша решил встать и ... .</em></p>	{}	TEXT	{}	Леша попробовал достать ногой но тоже не смог, поэтому Леша решил встать и РУКОЙ ПОДАТЬ.	{"Рукой подать"}	\N	2026-08-19 14:52:34.605	2026-08-20 06:00:28.217	{"Мера расстояния","Очень близко"}	\N	[{"url": "/uploads/1787151084462-555768116.png", "type": "IMAGE"}]
cmt07gixc000c15b93t56apz1	cmt07bsdw000615b9ueryj5f0	0	TEXT	<p>Закончите одним словом:</p><p><em>Антон очень любит "кулиты", она ему дороже жизни, поэтому можно сказать что Антон готов на все ... .</em></p>	{}	TEXT	{}	Радикулит	{}	\N	2026-08-19 14:47:06.192	2026-08-19 14:47:06.192	{Болезнь,Спина}	\N	[{"url": "/uploads/1787150805379-933685117.png", "type": "IMAGE"}]
cmt035mni000b15lrt0sqdyf7	cmsx0qahb000d15ilb2pmn2mq	0	TEXT	<p>Ответьте одним словом:</p><p><em>Чтобы спереди погладить, нужно сзади полизать, что это?</em></p>	{}	TEXT	{}	Почтовая марка или письмо	{марка,письмо}	\N	2026-08-19 12:46:39.342	2026-08-20 06:21:47.722	{Почта}	\N	[{"url": "/uploads/1787143675751-683070903.png", "type": "IMAGE"}]
cmt07uwx3000i15b97n0hxa2f	cmswzuzqz000c15ilh01n5rxq	0	TEXT	<p>Закончите фразеологизмом из 2х слов через дефис:</p><p><em>Дима и Коля не смогли зацепить проплывающий мимо пакет, поэтому они позвали Виталика, потому что у него ... .</em></p>	{}	TEXT	{}	.. они позвали Виталика, потому что у него РУКИ-КРЮКИ	{}	\N	2026-08-19 14:58:17.51	2026-08-20 05:57:03.207	{Неуклюжий}	\N	[{"url": "/uploads/1787151473346-298957215.png", "type": "IMAGE"}]
cmt083xhu000l15b9cqk3m0ym	cmswzuzqz000c15ilh01n5rxq	0	TEXT	<p>Закончите устойчивым выражением из 4х слов:</p><p><em>Если вы хотите, чтобы конечности вам не врали, то лучше спрашивать у рук, потому что ... .</em></p>	{}	TEXT	{}	... лучше спрашивать у рук, потому что В НОГАХ ПРАВДЫ НЕТ .	{"в ногах правды нет"}	\N	2026-08-19 15:05:18.161	2026-08-20 05:58:02.406	{}	\N	[{"url": "/uploads/1787151885763-320936341.png", "type": "IMAGE"}]
cmt08uewb000o15b9mgw5921z	cmswzuzqz000c15ilh01n5rxq	0	TEXT	<p>Заполните перывй пропуск устойчиывм выражением, а второй им же, но с одной замененной гласной:</p><p><em>Султан зашел в комнату и застыл в ужасе: все его жены были мертвы. Теперь султан находится в тяжелом состояни он [ПРОПУСК 1], потому что видел [ПРОПУСК 2] .</em></p><p>В ответ напишите устойчивое выражение.</p>	{}	TEXT	{}	Теперь султан находится в тяжелом состояни он УБИТЫЙ ГОРЕМ, потому что видел УБИТЫЙ ГАРЕМ	{"Убитый гарем"}	\N	2026-08-19 15:25:53.771	2026-08-20 05:59:56.671	{"Состояние человека после утраты"}	\N	[{"url": "/uploads/1787205178015-27318170.png", "type": "IMAGE"}]
cmt04cmrp000i15lrvxxdszgn	cmsx0qahb000d15ilb2pmn2mq	0	TEXT	<p>Ответьте одним словом:</p><p><em>Сначала в руках его держу, потом в дырочку встваляю, затем верчу немного, а в конце куда-то попадаю.</em></p>	{}	TEXT	{}	Ключ	{}	\N	2026-08-19 13:20:05.701	2026-08-20 06:22:51.247	{"4 буквы","Перед тем как попадаю еще и открываю"}	\N	[{"url": "/uploads/1787145573270-64912332.png", "type": "IMAGE"}]
cmt06e2c8000m15lrfq70caza	cmsx0qahb000d15ilb2pmn2mq	0	TEXT	<p>Ответьте одним словом:</p><p><em>Она утром голову теряет, но ближе к ночи обратно получает.</em></p>	{}	TEXT	{}	Подушка	{}	\N	2026-08-19 14:17:11.768	2026-08-20 06:25:53.13	{"Связано со сном",Мягкая}	\N	[{"url": "/uploads/1787149008051-406872408.png", "type": "IMAGE"}]
cmszwzvn0001z154zm4ui6xmn	cmssoikfm000515ygpnppss36	1	IMAGE_TEXT	<p>Закончите отрывок песни “Дымок” Ицык цыпера (Игорь Цыба):</p><p><em>Ну что могу сказать, ой-вей<br>Афганка — та повеселей<br>А так сидим, глядим в окно<br>Прибило ...</em></p>	{/uploads/1787217809399-39508154.png}	CHOICE	{"так, что всё равно","cука на говно","так, что поплыло","дымное весло"}	так, что всё равно	{}	\N	2026-08-19 09:54:13.332	2026-08-20 09:23:33.22	{}	\N	[{"url": "/uploads/1787209126175-423972368.mp3", "type": "AUDIO"}]
cmszz16me0025154z77fluu91	cmssoikfm000515ygpnppss36	5	TEXT	<p>Закончите куплет песни “Дымок” Ицык цыпера (Игорь Цыба):</p><p><em>Ну что могу сказать, ой-вей<br>Афганка — та повеселей<br>А так сидим, глядим в окно<br>Там ...</em></p>	{}	CHOICE	{"Дождь идёт уже давно","Там кто-то давится вином","Бабка доит молоко","Кент нас ждёт уже давно"}	Дождь идёт уже давно	{}	\N	2026-08-19 10:51:13.477	2026-08-20 07:14:29.908	{}	\N	[{"url": "/uploads/1787210067443-268006400.mp3", "type": "AUDIO"}]
cmszxc3vk0021154zedr0zoma	cmssoikfm000515ygpnppss36	2	IMAGE_TEXT	<p>Закончите отрывок из песни “Дымок” Ицык цыпера (Игорь Цыба)</p><p><em>Вдруг сзади кто-то нам: «Салам»<br>Ну мы в ответку: «Пополам»<br>Зашёл кентишка из Налива<br>Закинул ...</em></p>	{/uploads/1787217819785-215484426.png}	CHOICE	{"восемь литров пива","молча, смотрит криво","крепкого чифира","темку, дальше мимо"}	восемь литров пива	{}	\N	2026-08-19 10:03:43.88	2026-08-20 09:23:42.433	{}	\N	[{"url": "/uploads/1787209198382-5459798.mp3", "type": "AUDIO"}]
cmszyrwac0023154zw0s3vhc5	cmssoikfm000515ygpnppss36	3	TEXT	<p>Закончите отрывок из песни “Дымок” Ицык Цыпера (Игорь Цыба):</p><p><em>Ну что могу сказать, ой-вей<br>Афганка — та повеселей<br>А так сидим, глядим в окно<br>Вообще ...</em></p>	{}	CHOICE	{"Понравилось кино","Не видно ничего","прибило на говно","Не нужно ничего"}	прибило на говно	{}	\N	2026-08-19 10:44:00.179	2026-08-20 07:06:59.426	{}	\N	[{"url": "/uploads/1787209611043-222049783.mp3", "type": "AUDIO"}]
cmszzeyis0027154zyt22p995	cmssoikfm000515ygpnppss36	6	TEXT	<p>Закончите одним словом отрывок из песни “Нефертити” Ицык цыпера (Игорь Цыба):</p><p><em>Я брёл однажды по пустыне</em></p><p><em>В трусах, с бутылкою Мартини</em></p><p><em>Вокруг шикарный внешний вид</em></p><p><em>Песок и куча ...</em></p>	{}	TEXT	{}	пирамид	{пирамида}	\N	2026-08-19 11:01:56.162	2026-08-20 08:29:38.656	{"Пустыня в Египте"}	\N	[{"url": "/uploads/1787214572523-342771308.mp3", "type": "AUDIO"}]
cmszzkeiu0029154z7dwaet56	cmssoikfm000515ygpnppss36	7	TEXT	<p>Заполните пропуск в песне “Нефертити” Ицык Цыпера (Игорь Цыба):</p><p><em>Она была спокойна с виду<br>И мы зашли с ней в ...<br>А там прохлада, тишь стоит<br>И её тело как магнит</em></p>	{}	TEXT	{}	Пирамиду	{}	\N	2026-08-19 11:06:10.155	2026-08-20 08:34:11.14	{}	\N	[{"url": "/uploads/1787214845471-785326476.mp3", "type": "AUDIO"}]
cmssoikfm000615yg6fz7sjc6	cmssoikfm000515ygpnppss36	0	IMAGE_TEXT	<p>Закончите отрывок из песни “Дымок” Ицык цыпера (Игорь Цыба):</p><p><em>Натёр с ладошек ручничок</em></p><p><em>Смешал по дозе табачок</em></p><p><em>Курнул — ну вроде не навоз</em></p><p><em>Кентишка</em></p>	{/uploads/1787217794582-51131738.png}	CHOICE	{"дунул - парвоз","сплюнул на поднос","мне его принес","встанет на подсос"}	дунул - парвоз	{}	\N	2026-08-14 08:22:25.522	2026-08-20 09:23:26.357	{}	\N	[{"url": "/uploads/1787208893458-384127665.mp3", "type": "AUDIO"}]
cmt01yofq000715lrvgjfhtgw	cmssoikfm000515ygpnppss36	11	TEXT	<p>Закончите отрывок из песни “Патриот” Ицык цыпера (Игорь Цыба):</p><p><em>Их не увидишь у нас на линейке<br>Их жопы не киснут у нас на скамейке<br>Их братья не чалят по малолетке<br>Они все на тензе, ...</em></p>	{}	CHOICE	{"гламурные детки","тратят монетки","обезьяны на ветке","глотают таблетки"}	гламурные детки	{}	\N	2026-08-19 12:13:15.445	2026-08-20 09:22:07.021	{}	\N	[{"url": "/uploads/1787217719197-558420186.mp3", "type": "AUDIO"}]
cmt013n1h000115lr7i9bwigu	cmssoikfm000515ygpnppss36	8	TEXT	<p>Закончите отрывок песни “Нефертити” Ицык цыпера (Игорь Цыба):</p><p><em>А там прохлада, тишь стоит<br>И её тело как магнит<br>Который час? Какое время?<br>Четыре дня </em></p>	{}	CHOICE	{"верблюды в теме","тут жило племя","я с нею в теме","возились с нею"}	я с нею в теме	{}	\N	2026-08-19 11:49:07.272	2026-08-20 08:35:33.754	{}	\N	[{"url": "/uploads/1787214900769-626903388.mp3", "type": "AUDIO"}]
cmt01gwxn000315lrxavr69u4	cmssoikfm000515ygpnppss36	9	TEXT	<p>Закончите припев песни “Питерский гламур” Ицык цыпера (Игорь Цыба):</p><p><em>Быкует питерский гламур<br>А мы стригём на трассе с фур<br>От Салехарда до Кижей<br>Аля-улю, ...</em></p>	{}	CHOICE	{"гони гусей","коси траву","не трожь детей","стригать люблю"}	гони гусей	{}	\N	2026-08-19 11:59:26.624	2026-08-20 08:39:42.62	{}	\N	[{"url": "/uploads/1787215176952-393998799.mp3", "type": "AUDIO"}]
cmt01u32z000515lrlkuinq7j	cmssoikfm000515ygpnppss36	10	TEXT	<p>Закончите отрывок из песни “Питерский гламур” Ицык цыпера (Игорь Цыба):</p><p><em>Их не увидишь у нас на линейке<br>Их папы не ездят в пивбар на Копейке<br>Их имя не пишут у нас на заборе<br>Они все на тензе, ...</em></p>	{}	CHOICE	{"они все в запое","они все на море","их детки в конторе","их бабки в оффшоре"}	их бабки в оффшоре	{}	\N	2026-08-19 12:09:41.114	2026-08-20 09:20:45.522	{}	\N	[{"url": "/uploads/1787217638006-225561201.mp3", "type": "AUDIO"}]
\.


--
-- Data for Name: Series; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."Series" (id, title, number, description, "coverUrl", status, "publishedAt", "createdAt", "updatedAt") FROM stdin;
cmt06l1sr000n15lrwzdzaxgs	Непростой выпуск	3	\N	\N	DRAFT	\N	2026-08-19 14:22:37.657	2026-08-19 14:23:03.888
cmszsq4gm000a154zczpvlvhz	Веселый выпуск	2	<p>Туры наполнены веселыми вопросам со смешными картинками, вы точно получите кучу удовольствия и позитивных эмоций!</p>	\N	PUBLISHED	2026-08-20 07:14:58.657	2026-08-19 07:54:39.766	2026-08-20 07:14:58.658
cmssoikfv000715yghm3bbr6j	Пилотный выпуск	1	<p>Первый выпуск нашей игры, вас ждут три тура с веселыми вопросами.</p><p>Мы уверены, что вам понравится, удачи!</p>	\N	PUBLISHED	2026-08-20 08:25:36.569	2026-08-14 08:22:25.532	2026-08-20 08:25:36.572
\.


--
-- Data for Name: SeriesTour; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."SeriesTour" (id, "seriesId", "tourId", "sortOrder", "createdAt") FROM stdin;
cmsxbd1340001156n9y89sr7i	cmssoikfv000715yghm3bbr6j	cmswviw3x000215ilrypyhnqw	0	2026-08-17 14:13:03.041
cmssoikg2000915yg5xn4ongv	cmssoikfv000715yghm3bbr6j	cmssoikev000215ygpblgocrv	1	2026-08-14 08:22:25.538
cmszqn2zd0001154ztjkcxixg	cmssoikfv000715yghm3bbr6j	cmswzuzqz000c15ilh01n5rxq	2	2026-08-19 06:56:18.649
cmszsqhvi000c154z81c9ty9c	cmszsq4gm000a154zczpvlvhz	cmsy9qrl9001315octvt4vhd0	0	2026-08-19 07:54:57.129
cmszv0hj6001x154zfg5nhqkn	cmszsq4gm000a154zczpvlvhz	cmssoikfm000515ygpnppss36	1	2026-08-19 08:58:42.499
cmt030tx9000915lry7uuc21a	cmszsq4gm000a154zczpvlvhz	cmsx0qahb000d15ilb2pmn2mq	2	2026-08-19 12:42:55.486
cmt07bsed000815b9ybxb0uha	cmt06l1sr000n15lrwzdzaxgs	cmt07bsdw000615b9ueryj5f0	0	2026-08-19 14:43:25.189
cmt1s5mmw000615vhahlxdwgk	cmt06l1sr000n15lrwzdzaxgs	cmt1s5mmp000415vhg71x4qw3	1	2026-08-20 17:14:15.896
\.


--
-- Data for Name: TeamAccount; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."TeamAccount" (id, name, email, "passwordHash", "logoUrl", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Tour; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public."Tour" (id, title, rules, "defaultPoints", "createdAt", "updatedAt", "defaultTimeLimitSec", "mediaUrls", "limitQuestionsToTeamCount") FROM stdin;
cmsy9qrl9001315octvt4vhd0	Узнаваемый косплей	<p>Задание этого тура будет представлено фотографией косплея на известных персонажей из фильмов, мультфильмов или даже игр. Ваша задача назвать персонажа</p><p>Удачи!</p>	2	2026-08-18 06:15:30.833	2026-08-18 06:15:30.833	60	{}	f
cmssoikev000215ygpblgocrv	Мемы	<p>В заданиии всегда будет фигурировать мем, ваша задача внимательно прочитать задание и дать правильный ответ.</p><p><strong>Для примера</strong> выше задание звучит так:</p><p><em>Какая фраза скрыта за смайликом?</em></p><p><strong>Правильный ответ:</strong><em> Превед!</em></p><p>Удачи!</p><p></p>	2	2026-08-14 08:22:25.495	2026-08-18 06:09:17.263	60	{/uploads/1786949508580-258086072.png}	f
cmswxaf6m000a15ilhslj3ut3	Музыка	<p>Общие вопросы о музыке, песнях и музыкантах.</p><p><strong>Пример вопроса:</strong></p><p><em>Кем А. Пугачева не просила быть в своей песне “Будь или не будь”</em></p><p><strong>Вариаты ответов:</strong></p><ol type="a"><li><p>мальчиком</p></li><li><p>зайчиком</p></li><li><p>деточкой</p></li><li><p>котиком</p></li></ol><p><strong>Правильный ответ:</strong> d. котиком</p><p>Удачи!</p>	2	2026-08-17 07:39:06.695	2026-08-18 06:09:38.452	60	{}	f
cmssoikfm000515ygpnppss36	Куплеты	<p>Задание представлено отрывком из песни самых разных исполнителей, ваша задача дополнить отрывок одним из предложенных вариантов.</p><p><strong>Пример задания:</strong></p><p>Закончите куплет песни Шуры «Ты не верь слезам»</p><p><em>Растекается свет невидимый</em></p><p><em>Всё отмечено старым именем</em></p><p><em>Руки скованы вечным холодом</em></p><p><em>Только ...</em></p><p><strong>Правильный ответ:</strong> головы непокорные</p><p>Удачи!</p>	2	2026-08-14 08:22:25.522	2026-08-19 09:35:58.328	60	{}	f
cmswy18vj000b15ilw4ymx8y7	Факты	<p>Задания этого тура основаны на известных фактах, ваша задача прочитат вопрос и выбрать правильный вариант ответа</p><p><strong>Пример вопроса:</strong></p><p><em>В одном из интервью, основатель ВК и Telegram - Пвел Дуров упомянул, что является биологическим отцом более 100 детей, поскольку многие годы был донором спермы в 12 странах мира. Но помимо этого у дурова есть и официально признанные дети.<br>Сколько официально признанных детей у Павла Дурова?</em></p><p><strong>Варианты ответов:</strong></p><ol type="a"><li><p>1</p></li><li><p>6</p></li><li><p>13</p></li><li><p>19</p></li></ol><p><strong>Правильный ответ:</strong> b.6</p><p>Удачи!</p>	2	2026-08-17 07:59:58.22	2026-08-18 06:11:34.966	60	{}	f
cmswwxdio000715illhiff9o3	Цитаты	<p>Здание будет представлено известной цитатой с пропущенными словами ваша задача заполнить пробелы.</p><p><strong>Например:</strong></p><p>Закончите цитату Ольги Бузовой:</p><p><code>«</code><em>Он не чужой мужик, он … мужик</em><code>»</code></p><p><strong>Варианты ответов:</strong></p><ol type="a"><li><p>настоящий</p></li><li><p>ничей</p></li><li><p>злой</p></li><li><p>сладкий</p></li></ol><p><strong>Правильный ответ:</strong> b. ничей</p><p>Удачи!</p>	2	2026-08-17 07:28:58.03	2026-08-18 06:12:20.317	60	{}	f
cmswwgct4000615ilzal5o7lm	Персонажи	<p>Задание будет представлено фтографией персонажа из фильма, мультфильма или игры.</p><p>Иногда это могут быть просто интересные личноти котороые точно заслужили носить почетное звание персонажа, ваша задача написать его имя.</p><p><strong>Правильный ответ</strong> для фотографии выше: <em>Борат</em></p><p>Удачи!</p>	2	2026-08-17 07:15:43.958	2026-08-19 12:35:27.223	60	{/uploads/1786950741435-371255634.png}	f
cmswviw3x000215ilrypyhnqw	Знаменитости	<p>В задании с помощью картинок будет зашифровано имя или псевдоним знаменитости, ваша задача решить ребус за отведенное время и написать правильный ответ.</p><p><strong>Например</strong>, задание выше можно решить как:</p><p><em>Клавиатура (</em><strong><em>Клава</em></strong><em>) + </em><strong><em>Кока</em></strong><em>-Кола = </em><strong><em>Клава Кока</em></strong></p><p><strong>Правильный ответ:<em> </em></strong><em>Клава Кока</em></p><p>Удачи!</p>	2	2026-08-17 06:49:42.669	2026-08-18 06:04:43.888	60	{/uploads/1786949379947-665889733.webp,/uploads/1786949380074-280156890.jpg}	f
cmswzuzqz000c15ilh01n5rxq	Каламбуры	<p>Задание представляет из себя текстовое описание а иногда картинку в которых  с помощью каламбура зашифрована крылатая фраза, устойчивое выражение или пословица.</p><p><strong>Пример задания:</strong></p><p><em>Почему мальчик с писями вместо рук никогда не сгорит в пожаре?</em></p><p><strong>Правильный ответ:</strong> <em>Рукописи не горят</em></p><p>Удачи!</p>	3	2026-08-17 08:51:05.7	2026-08-19 06:57:00.033	90	{}	t
cmsx0qahb000d15ilb2pmn2mq	Загадки	<p><strong>Пример задания: </strong><em>Что сначала твёрдое, потом мягкое, а после использования становится мокрым?</em></p><p><strong>Правильный ответ:</strong> <em>Жвачка</em></p><p>Удачи!</p>	3	2026-08-17 09:15:25.935	2026-08-19 12:57:39.451	90	{}	t
cmt07bsdw000615b9ueryj5f0	Каламбуры	<p>Задание представляет из себя текстовое описание а иногда картинку в которых  с помощью каламбура зашифрована крылатая фраза, устойчивое выражение или пословица.</p><p><strong>Пример задания:</strong></p><p><em>Почему мальчик с писями вместо рук никогда не сгорит в пожаре?</em></p><p><strong>Правильный ответ:</strong> <em>Рукописи не горят</em></p><p>Удачи!</p>	3	2026-08-19 14:43:25.172	2026-08-19 14:43:25.172	90	{}	t
cmt1s5mmp000415vhg71x4qw3	Загадки	<p><strong>Пример задания: </strong><em>Что сначала твёрдое, потом мягкое, а после использования становится мокрым?</em></p><p><strong>Правильный ответ:</strong> <em>Жвачка</em></p><p>Удачи!</p>	3	2026-08-20 17:14:15.889	2026-08-20 17:14:15.889	90	{}	t
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: game
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
f5172c1b-23f0-4366-8456-55d16f292418	1284372680beecd07cad95faa3d93cf691f90b42906167797fe7a29a54e19e8d	2026-08-14 11:22:23.956222+03	20260806132637_init	\N	\N	2026-08-14 11:22:23.922213+03	1
0737a003-5437-402d-8de8-9d02558434e2	2d1afa1d4528875887ac8e910d238d5aeb0bc8810baf02973386137e4b1718e8	2026-08-14 11:22:23.966691+03	20260806141324_add_tour_default_time_limit	\N	\N	2026-08-14 11:22:23.958118+03	1
7545022e-0897-46d5-8e66-3e9ad59d809a	7c1cc64fe779397e8efe825751d6e7553570d7d8fd61ddcd6618fa3d23698d62	2026-08-14 11:22:23.982834+03	20260806152700_question_hints_array	\N	\N	2026-08-14 11:22:23.96874+03	1
609f78bf-8608-4fda-b71d-b8e082853d4e	6e142ce42f8709708c5377f953f898e8372f435fe6f032d2b3b0ab1c8fae94dd	2026-08-14 11:22:24.003738+03	20260806221500_drop_question_explanation	\N	\N	2026-08-14 11:22:23.987789+03	1
a8d6f424-c0a6-47ef-a721-4c2397d7f994	e1f87cac36d70851562f27ecce5aa834fa89aa9974c4eef22d14608e7371ffdc	2026-08-14 11:22:24.022273+03	20260806223000_add_question_points	\N	\N	2026-08-14 11:22:24.008747+03	1
03504c24-cc85-42a7-a7a9-976bcc6cb6b5	e4ea21de163d20d35bcad5a70025e3e6a25ba7bbb8b96d58f1734dfb5e7b12e1	2026-08-14 11:22:24.039843+03	20260807152600_tours_as_library	\N	\N	2026-08-14 11:22:24.024748+03	1
babc89ca-f5d7-422e-ae0e-0628f9954651	92e1ce1031784fcb8a800ce012b6a4fb22fbab0cc5165cdf5307447ada92b0f1	2026-08-17 09:41:53.425337+03	20260814150000_add_tour_media_urls	\N	\N	2026-08-17 09:41:53.396141+03	1
07e94960-f688-45ca-981a-ba6691045b78	a0be1c540bb94d17a8c0c82eff8f972b1646c89fb611cb37c80ddfccbeb4eb6a	2026-08-17 09:41:53.435263+03	20260816130000_add_question_answer_media	\N	\N	2026-08-17 09:41:53.427346+03	1
aa576986-0d11-4504-8281-5b380281bf9c	319a7165e67b92563bf921216811fa61c46b6807621a73837add62c57145934c	2026-08-17 09:41:53.462927+03	20260816140000_question_answer_media_array	\N	\N	2026-08-17 09:41:53.437328+03	1
5fc23e36-4328-4c89-af03-808a933f8469	79314642f9ec5aa4e6523670b34e698dc06ba58a948c3cc46cbfdd160dc07769	2026-08-19 09:43:05.927024+03	20260819100000_tour_limit_questions_to_team_count	\N	\N	2026-08-19 09:43:05.862043+03	1
\.


--
-- Name: AdminUser AdminUser_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."AdminUser"
    ADD CONSTRAINT "AdminUser_pkey" PRIMARY KEY (id);


--
-- Name: GameRoom GameRoom_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."GameRoom"
    ADD CONSTRAINT "GameRoom_pkey" PRIMARY KEY (id);


--
-- Name: GameTeam GameTeam_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."GameTeam"
    ADD CONSTRAINT "GameTeam_pkey" PRIMARY KEY (id);


--
-- Name: MediaFile MediaFile_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."MediaFile"
    ADD CONSTRAINT "MediaFile_pkey" PRIMARY KEY (id);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id);


--
-- Name: SeriesTour SeriesTour_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."SeriesTour"
    ADD CONSTRAINT "SeriesTour_pkey" PRIMARY KEY (id);


--
-- Name: Series Series_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."Series"
    ADD CONSTRAINT "Series_pkey" PRIMARY KEY (id);


--
-- Name: TeamAccount TeamAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."TeamAccount"
    ADD CONSTRAINT "TeamAccount_pkey" PRIMARY KEY (id);


--
-- Name: Tour Tour_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."Tour"
    ADD CONSTRAINT "Tour_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AdminUser_email_key; Type: INDEX; Schema: public; Owner: game
--

CREATE UNIQUE INDEX "AdminUser_email_key" ON public."AdminUser" USING btree (email);


--
-- Name: GameRoom_code_key; Type: INDEX; Schema: public; Owner: game
--

CREATE UNIQUE INDEX "GameRoom_code_key" ON public."GameRoom" USING btree (code);


--
-- Name: GameTeam_roomId_idx; Type: INDEX; Schema: public; Owner: game
--

CREATE INDEX "GameTeam_roomId_idx" ON public."GameTeam" USING btree ("roomId");


--
-- Name: Question_tourId_idx; Type: INDEX; Schema: public; Owner: game
--

CREATE INDEX "Question_tourId_idx" ON public."Question" USING btree ("tourId");


--
-- Name: SeriesTour_seriesId_idx; Type: INDEX; Schema: public; Owner: game
--

CREATE INDEX "SeriesTour_seriesId_idx" ON public."SeriesTour" USING btree ("seriesId");


--
-- Name: SeriesTour_seriesId_tourId_key; Type: INDEX; Schema: public; Owner: game
--

CREATE UNIQUE INDEX "SeriesTour_seriesId_tourId_key" ON public."SeriesTour" USING btree ("seriesId", "tourId");


--
-- Name: SeriesTour_tourId_idx; Type: INDEX; Schema: public; Owner: game
--

CREATE INDEX "SeriesTour_tourId_idx" ON public."SeriesTour" USING btree ("tourId");


--
-- Name: Series_number_key; Type: INDEX; Schema: public; Owner: game
--

CREATE UNIQUE INDEX "Series_number_key" ON public."Series" USING btree (number);


--
-- Name: TeamAccount_email_key; Type: INDEX; Schema: public; Owner: game
--

CREATE UNIQUE INDEX "TeamAccount_email_key" ON public."TeamAccount" USING btree (email);


--
-- Name: Tour_title_idx; Type: INDEX; Schema: public; Owner: game
--

CREATE INDEX "Tour_title_idx" ON public."Tour" USING btree (title);


--
-- Name: GameRoom GameRoom_seriesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."GameRoom"
    ADD CONSTRAINT "GameRoom_seriesId_fkey" FOREIGN KEY ("seriesId") REFERENCES public."Series"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GameTeam GameTeam_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."GameTeam"
    ADD CONSTRAINT "GameTeam_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."GameRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GameTeam GameTeam_teamAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."GameTeam"
    ADD CONSTRAINT "GameTeam_teamAccountId_fkey" FOREIGN KEY ("teamAccountId") REFERENCES public."TeamAccount"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Question Question_tourId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_tourId_fkey" FOREIGN KEY ("tourId") REFERENCES public."Tour"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SeriesTour SeriesTour_seriesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."SeriesTour"
    ADD CONSTRAINT "SeriesTour_seriesId_fkey" FOREIGN KEY ("seriesId") REFERENCES public."Series"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SeriesTour SeriesTour_tourId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: game
--

ALTER TABLE ONLY public."SeriesTour"
    ADD CONSTRAINT "SeriesTour_tourId_fkey" FOREIGN KEY ("tourId") REFERENCES public."Tour"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict O87X5d6cIeQJKHghrM3QNpq8HYY6i2a3b392uoEL2BAXCc7lVSI0qba2H6kzurV

